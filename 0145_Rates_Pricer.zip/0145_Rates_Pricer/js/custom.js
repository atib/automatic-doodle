$(document).ready(function(){

	initSearchBar();
	initTableSort();
	initFaveToggle();
	setDeleteAction();
	setFaveAction();
	setAddTabAction();
	setEditTabAction();
	setTableEditActions()
	startTickingPrices();
	addTab();
	// addStrategy("eur 1y 2s5s10s swap fly", false);
	// addStrategy("jpy 6m 2s5s10s recvr fly", false);
	// addStrategy("gbp 5y5y straddle swap", false);
	// addStrategy("gbp 5y10y swap", false);
	// addStrategy("eur 5y10y", false)
	addRow()
});

var rate_k, rowid;

function initSearchBar() {
	typeof $.typeahead === 'function' && $.typeahead({
		input: ".js-typeahead",
		minLength: 1,
		maxItem: 20,
		hint: true,
		dropdownFilter: false,
		cancelButton: true,
		searchOnFocus: true,
		template: "{{structureDescription}}, <small><em>{{structureType}}</em></small><span class='badge pull-right badge-{{popular}}'>&nbsp;</span>",
		emptyTemplate: "no result for {{query}}",
		display: ["structureDescription", "structureType", "popular"],
		source: data,
		correlativeTemplate: true,
		callback: {
			onSearch: function(node, query) {

					if (query.includes('@')) {
 	                var rate = query.toLowerCase().split('@'); 

	                if (rate[1].toLowerCase().includes('k')) {
	                    rate_k = rate[1].substring(0, rate[1].indexOf('k')); 
	                	console.log("onSearch " + rate_k);
	                } else {
	                	rate_k = rate[1].replace(/[a-zA-Z]/g, ' ');
	                }

                	this.query = this.query.toLowerCase().replace(rate[1],' ');    
                	this.query = this.query.trim().replace(/@/g, ' ');
                	this.query = this.query.trim();
				}

				return;
			},

			onClickAfter: function (node, a, item, event) {
				event.preventDefault();
				addStrategy(item.structureDescription, true);
				rate_k = '';
				$('.js-result-container').text('');
				$('.js-typeahead').val('');
				
			},
			
			onResult: function (node, query, obj, objCount) {
				event.preventDefault();

				var text = "";
				if (query !== "") {
					text = objCount + ' elements matching "' + query + '"';
				}
				$('.js-result-container').text(text);
			},
			
			onSubmit: function (node, form, item, event) {
				event.preventDefault();
				console.log(event.keyCode)
				addStrategy($('.js-typeahead').val(), true);
				rate_k = ''; 
				$('.js-result-container').text('');
				$('.js-typeahead').val('');

			}
		}
	});
}

function initFaveToggle() {
	$('#toggleFaves').click(function() {
		if ($('#faves').css("width") != "250px") {
			$('#faves').css("width", "250px");
			$('#main').css("margin-right", "235px");
		} else {
			$('#faves').css("width", "0px");
			$('#main').css("margin-right", "-15px");
		}
	});
}


function initTableSort() {
	$(".pricecontainer > tbody ").sortable({
		items: "> tr",
		appendTo: "parent",
		helper: "clone",
		cursor: "move",
		handle: "> td:nth-child(1)",
		forcePlaceholderSize: true,  
		start: function(event, ui) {
			ui.placeholder.height(ui.item.height());
		},  
		change: function(event, ui) {
			ui.placeholder.height(ui.item.height());
		}
	});

}

function getRnd(min, max) {
	return Math.floor(Math.random() * (max - min + 1) ) + min;
}

function decimalRnd(min, max) {
	return (Math.random() * (max - min) + min).toFixed(1)
}


function startTickingPrices() {

	setInterval(
		function(){
			$('table.pricecontainer > tbody > tr').each(function() {
				if ($(this).children().find('.rates_pricer_option').val() == 'bp') {	
					if (getRnd(0,10) > 7) {				
						var cell = $(this).find("td").eq(4);
						var curval = Number(cell.html());
						var rand = getRnd(-2,2);
						cell.html(curval + rand);
						cell.removeClass();
						if (rand > 0 ) {
							cell.addClass("flashup");
						} else if (rand < 0 ) {
							cell.addClass("flashdown");
						}
					}
					var cell_atmf = $(this).find('.atmf_rtp');
					var rand_atmf = decimalRnd(0.8, 2.1);
					cell_atmf.html(rand_atmf); 
					
					if (getRnd(0, 600000)) {
						var cell_pv = $(this).find('.pv_rtp');
						var rand_pv = getRnd(0, 600000);
						cell_pv.html(rand_pv);
					}

					var cell_dv01 = $(this).find('.dv01_rtp');
					var dv_01_current = cell_dv01.html();
					console.log(dv_01_current);
					var rand_dv_small = getRnd(0,10);
					var rand_dv_large = getRnd(0,200000);

					cell_dv01.html(rand_dv_small);

					if (dv_01_current > 9) {
						cell_dv01.html(rand_dv_large);
					} else if (dv_01_current > 160000) {
						cell_dv01.html(rand_dv_small);
					}
				}
			});
		}, 2000);
}


function loopLegs(legNumber, ts) {
	
	var repeatedLegs, legs; 
	
	legs = 	 `<table id='`+ts+`_legs' class='table table-condensed pricerow-legs'>
			 	<tbody>`;
		
	legs += `<tr class='legs-header'>
				<th></th>
				<th>Direction</th>
				<th>Start</th>
				<th>End</th>
				<th>Type</th>
				<th>Rates</th>
			</tr>`;

	if (rate_k == null || rate_k == '') {
		rate_k = 'Rate';	
	}

	repeatedLegs = `<tr class='leg-table'>
						<td></td>
						<td><input value='Direction'/></td>
						<td><input value='Start date'/>
						</td><td><input value='End date'/></td>
						<td><input value='Type'/></td>
						<td><input value='`+ rate_k +`'/></td>
						<td></td>
						<td></td>
						<td></td>
					</tr>`;

	while (legNumber > 0) {
		legs += repeatedLegs; 
		legNumber --;
	}
	legs += `</tbody>
			</table>`;

	return legs;
}



function setTableEditActions() {

	$(".tab-content").on("keypress", ".table-input", function(event){
		if ( event.which == 13 || event.which == 27 || event.which == 9) {
			event.preventDefault();
			$(this).blur();
		 }
	});

	$(".tab-content").on("blur", ".table-input-ccy",  function(){
		rowCCY = $(this).val();

		if (rowCCY.length != 3 ) {
			$(this).addClass('error');
		} else {
			$(this).removeClass('error')
		}
	});

	$(".tab-content").on("keydown", ".table-input-strategy",  function(){
		if (event.which == 13 || event.which == 9){
			var rowCCY = $(this).parents("td").eq(0).siblings().eq(0).children().val();
			var newStrategy = rowCCY + $(this).val().toString();		
			var rowid = $(this).parents("table").attr("id");
			setStrategy(rowid, newStrategy);
		} 
	});

	$(".tab-content").on("click", ".edit-row", function(){
		var rowid = $(this).parents("table").attr("id");	
		$('#' + rowid +'_legs').slideToggle(100);
	});
}


function addRow() {

	rowid = "row_" + Math.random().toString(36).substring(3);

	var markup = `<tr><td><i class='fa fa-ellipsis-v'</i></td>
		 <td>
			<table id='` + rowid + `' class='table table-condensed pricetable'>
			 	<tbody>
				 <tr class='pricerow'>
					 <td><input class='table-input table-input-ccy' value=''/></td>
					 <td><input class='table-input table-input-strategy' value=''/></td>
					 <td class='level_rtp'> </td>
					 <td>
					 	<select id='`+rowid+`_options' class='rates_pricer_option form-control'>
					 		<option selected='selected' value='bp'>bp</option>
					 		<option value='cts'>cts</option>
					 		<option value='k'>k</option>
					 	</select>
					 </td>
					 <td class='atmf_rtp'> </td>
					 <td class='pv_rtp'> </td>
					 <td class='dv01_rtp'> </td>
					 <td><a class='btn btn-success btn-rfs' href='https://uat.citivelocity.com/rfq-web/multileg/' target='_new'>RFS &nbsp; <i class='fa fa-paper-plane' aria-hidden='true'></i></a></td>
					 <td><a class='btn edit-row'><i class='fa fa-pencil' aria-hidden='true'></i></a></td>
					 <td><a class='btn fave-row'><i class='fa fa-star-o' aria-hidden='true'></i></a></td>
					 <td><a class='btn delete-row'><i class='fa fa-trash-o' aria-hidden='true'></i></a></td>
				 </tr>
				 </tbody>
			</table>
		</td>
	</tr>`;

	$('div.tab-content > div.active table.pricecontainer').children("tbody").append(markup);

	return rowid;
}

function addStrategy(strategyText, userAdded) {
	
	rowid = addRow();
	setStrategy(rowid, strategyText);

	if (userAdded)
		$('#'+rowid+'_legs').slideToggle()
}


function setStrategy(rowid, strategyText) {

	var ccy = strategyText.substring(0,3);
	strategyText = strategyText.substring(3)

	var row = $('#'+rowid);

	if (!strategyText) {
		console.log('text empty')
	} else {
		console.log('not empty')
		addRow()
	}

	//if "fly" then
	if (strategyText.includes("fly") || strategyText.includes("fwd")) {
		if ($('#' + rowid +'_legs').length == 0) {
			//it *wasn't* already a fly, add legs
			var markup = loopLegs(3, rowid);

			//add legs
			row.after(markup)
			if (rate_k != 'Rate') {
				row.children().find('.level_rtp').text(rate_k);
				row.children().find('.rates_pricer_option').val('k');
			}
		}
		//always show edit button for fly
		row.children().find(".edit-row").show();
	} else if(strategyText.includes("straddle") || strategyText.includes("strangle") || strategyText.includes("swap")){

		if ($('#'+rowid+'_legs').length == 0){
			var markup = loopLegs(2, rowid); 
			row.after(markup); 
			if (rate_k != 'Rate') {
				row.children().find('.level_rtp').text(rate_k);
				row.children().find('.rates_pricer_option').val('k');
			}
		}
		row.children().find(".edit-row").show();
	} else {
		//it *was* a fly so delete legs
		if ($('#' + rowid +'_legs').length) {
			$('#'+rowid+'_legs').remove();
		}
		//always hide edit button for non-fly
		row.children().find(".edit-row").hide();
	}

	strategyText = strategyText.replace("swap", "");

	//within row, set table-input-ccy to CCY
	$('#'+rowid+' .table-input-ccy').val(ccy);

	//within row, set table-input-strategy to strategyText
	$('#'+rowid+' .table-input-strategy').val(strategyText);

	//Init Table Sort needs to set each time 
	initTableSort();
}

function setDeleteAction() {
	$(".tab-content").on("click", ".delete-row", function(){
		var cell = $(this).parents("tr").find("td").eq(1);
		$(this).parents("tr").remove();
		var strategyText = cell.html();
		var ds = getTime();
		var markup = "<tr><td>" + ds + "</td><td>" + strategyText + "</td><td><Hi></Hi>t</td><td><a class='btn fave-row'><i class='fa fa-star-o' aria-hidden='true'></i></a></td></tr>";
		$('#history').children("tbody").append(markup);
	});
}

function setFaveAction(){

	$(".tab-content").on("click", ".fave-row", function(){
		var cell = $(this).parents("tr").find("td").eq(1);
		addFave(cell.html());
	});

	$("#fave-links").on("click", ".fave", function(){
		addRow($(this).html());
	});
}

function addFave(faveText) {
	var markup = "<a class='fave'>" + faveText + "</a>";
	if ($("#fave-links > a:contains('" + faveText + "')").length == 0) {
		$('#fave-links').append(markup);
	}

	console.log('markup', markup );
}

function setEditTabAction()
{
	$(".nav-tabs").on("mousedown", "li > div > a.deleteTab", function(){
		var tab = $(this).parents("li");
		var tabid = tab.attr('id');
		var tbid = tabid.substring(4);
		$("#" + tbid).remove();
		$("#" + tabid).remove();
		$(".nav-tabs li a").first().tab('show');
	});

	$(".nav-tabs").on("dblclick", "li > a", function(){
		var tab = $(this).parents("li");
		if (tab.attr('id') != "historyTab") {
			$(this).hide();
			tab.append("<div><input id='renametab' type='text' value='" + $(this).html() + "'/><a class='deleteTab'><i class='fa fa-times'></i></a></div>");
			$('#renametab').focus();
			$('#renametab').select();
		}
	});

	$(".nav-tabs").on("keypress", "input", function(event){
		if ( event.which == 13 || event.which == 27) {
			event.preventDefault();
			$(this).blur();
		 }
	});

	$(".nav-tabs").on("blur", "input", function(){
		if ($(this)) {
			var tab = $(this).parents("li");
			var link = tab.find("a");
			var text = $(this).val();
			if (text != "") {
				link.html(text);
			}
			link.show();
			$(this).parent().remove();
		}
	});	

}

function setAddTabAction() {
	$("#addTab").click(function(){
		addTab();
	});
}

function addTab() {
	var ts = Math.round(new Date().getTime());

	//Add tab
	var tabCode = `	<li id='tab_` + ts + `'>
						<a data-toggle='tab' href='#` + ts + `'>New Tab</a>
					</li>`;

	$(tabCode).insertBefore("#historyTab");

	//Add Body
	var tabBody = `<div id='`+ts+`'class='tab-pane fade'><br/>
				  <table class='table table-condensed pricecontainer reorder'>
				  <thead>
				  	<tr><th></th>
				  		<th>
					  		<table class='table table-condensed pricerow-header'>
					  			<thead>
						  		<tr>
						  			<th>CCY</th>
						  			<th>Structure</th>
						  			<th>Level</th>
						  			<th>Unit</th>
						  			<th>ATMF</th>
						  			<th>PV</th>
						  			<th>DV01</th>
						  			<th></th>
						  			<th></th>
						  			<th></th>
						  			<th></th>
						  		</tr>
						  		</thead>
					  		</table>
				  		</th>
				  	</tr></thead>
				  	<tbody>
				  </div>`;

	$(tabBody).insertBefore("#historyBody");

	//Activate new tab
	$(".nav-tabs li#tab_" + ts + " a").tab('show');
}

function checkTime(i) {
	return (i < 10) ? "0" + i : i;
}

function getTime() {
	var today = new Date();
	return checkTime(today.getHours()) + ":" + checkTime(today.getMinutes()) + ":" + checkTime(today.getSeconds());
}



