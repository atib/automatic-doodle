$(document).ready(function(){
	initSearchBar();
	initTableSort();
	setDeleteAction();
	setFaveAction();
	setEditAction();
	setAddTabAction();
	setEditTabAction();
	startTickingPrices();

	addTab();
	addRow("eur 1y 2s5s10s swap fly");
	addRow("eur 6m 2s5s10s recvr fly");
	addRow("gbp 5y5y straddle");

	$('#toggleFaves').click(function() {
		if ($('#faves').css("width") != "250px") {
			$('#faves').css("width", "250px");
			$('#main').css("margin-right", "235px");
		} else {
			$('#faves').css("width", "0px");
			$('#main').css("margin-right", "-15px");
		}
	});

});

function initSearchBar() {
	typeof $.typeahead === 'function' && $.typeahead({
		input: ".js-typeahead",
		minLength: 1,
		maxItem: 20,
		order: "asc",
		hint: true,
		dropdownFilter: false,
		cancelButton: true,
		template: "{{structureDescription}}, <small><em>{{structureType}}</em></small><span class='badge pull-right badge-{{popular}}'>&nbsp;</span>",
		emptyTemplate: "no result for {{query}}",
		display: ["structureDescription", "structureType", "popular"],
		source: data,
		correlativeTemplate: true,
		callback: {
			onClickAfter: function (node, a, item, event) {
				event.preventDefault();
				addRow(item.structureDescription);
				$('.js-result-container').text('');
				$('.js-typeahead').val('');
			},
			onResult: function (node, query, obj, objCount) {

				console.log(objCount)

				var text = "";
				if (query !== "") {
					text = objCount + ' elements matching "' + query + '"';
				}
				$('.js-result-container').text(text);

			},
			onSubmit: function (node, form, item, event) {
				event.preventDefault();
				//Do Nothing
			}
		}
	});
}

function initTableSort() {
	$(".reorder tbody").sortable({
		items: "> tr",
		appendTo: "parent",
		helper: "clone",
		cursor: "move",
		handle: "td:nth-child(1)"
	});
}
	
function getRnd(min, max) {
	return Math.floor(Math.random() * (max - min + 1) ) + min;
}

function startTickingPrices() {
	setInterval(
		function(){ 
			$('table.pricetable > tbody > tr').each(function() {
				if (getRnd(0,10) > 6) {
					var cell = $(this).find("td").eq(3);
					var curval = Number(cell.html());
					var rand = getRnd(-2,2);
					cell.html(curval + rand);
					cell.removeClass();
					if (rand > 0 ) { 
						cell.addClass("flashup"); 
					} else if (rand < 0 ) { 
						cell.addClass("flashdown"); 
					}
				}
			});
		}, 1000);
}

function addRow(structureText) {
	var ts = Math.round(new Date().getTime());
	var markup = "<tr class='newrow' id='item_" + ts + "'><td><i class='fa fa-ellipsis-v' aria-hidden='true'></i></td><td>" + structureText + "</td><td><input class='form-control' type='text' value='100,000,000'/></td><td>-9.00</td><td><select class='form-control'><option selected='selected'>bp</option><option>cts</option><option>k</option></select></td><td><a class='btn btn-default edit-row'>Edit &nbsp; <i class='fa fa-pencil' aria-hidden='true'></i></a></td><td><a class='btn btn-success btn-rfs' href='https://uat.citivelocity.com/rfq-web/multileg/' target='_new'>RFS &nbsp; <i class='fa fa-paper-plane' aria-hidden='true'></i></a></td><td><a class='btn fave-row'><i class='fa fa-star-o' aria-hidden='true'></i></a></td><td><a class='btn delete-row'><i class='fa fa-trash-o' aria-hidden='true'></i></a></td></tr>";
	$('div.tab-content > div.active table.pricetable').children("tbody").append(markup);
	unsetNewRows();
	initTableSort();
}

function setDeleteAction() {
	$(".tab-content").on("click", ".delete-row", function(){
		var cell = $(this).parents("tr").find("td").eq(1);
		$(this).parents("tr").remove();
		var structureText = cell.html();
		var ds = getTime();
		var markup = "<tr class='newrow'><td>" + ds + "</td><td>" + structureText + "</td><td>Hit</td><td><a class='btn fave-row'><i class='fa fa-star-o' aria-hidden='true'></i></a></td></tr>";
		$('#history').children("tbody").append(markup);
		unsetNewRows();
	});
}

function setFaveAction()
{
	$(".tab-content").on("click", ".fave-row", function(){
		var cell = $(this).parents("tr").find("td").eq(1);
		addFave(cell.html());
	});

	$("#fave-links").on("click", ".fave", function(){
		addRow($(this).html());
	});
}

function addFave(faveText) {
	var markup = "<a class='fave'>" + faveText + "</a>";
	if ($("#fave-links > a:contains('" + faveText + "')").length == 0) {
		$('#fave-links').append(markup);
	}		
}

function setEditAction()
{
	$(".tab-content").on("click", ".edit-row", function(){
		var cell = $(this).parents("tr").find("td").eq(1);
		$('#modalName').val(cell.html());
		$('#itemid').val($(this).parents("tr").attr("id"));
		$('#modalEdit').modal('show');
	});

	$(".btn-dorename").click(function(){
		var itemid = $('#itemid').val();
		var cell = $("#" + itemid).find("td").eq(1);
		cell.html($('#modalName').val());
	});
}

function setEditTabAction()
{
	$(".nav-tabs").on("mousedown", "li > div > a.deleteTab", function(){
		var tab = $(this).parents("li");
		var tabid = tab.attr('id');
		var tbid = tabid.substring(4);
		$("#" + tbid).remove();
		$("#" + tabid).remove();
		$(".nav-tabs li a").first().tab('show');
	});

	$(".nav-tabs").on("dblclick", "li > a", function(){
		var tab = $(this).parents("li");
		if (tab.attr('id') != "historyTab") {
			$(this).hide();
			tab.append("<div><input id='renametab' type='text' value='" + $(this).html() + "'/><a class='deleteTab'><i class='fa fa-times'></i></a></div>");
			$('#renametab').focus();
			$('#renametab').select();
		}
	});

	$(".nav-tabs").on("keypress", "input", function(event){
		if ( event.which == 13 || event.which == 27) {
			event.preventDefault();
			$(this).blur();
		 }
	});

	$(".nav-tabs").on("blur", "input", function(){
		if ($(this)) {
			var tab = $(this).parents("li");
			var link = tab.find("a");
			var text = $(this).val();
			if (text != "") {
				link.html(text);
			}
			link.show();
			$(this).parent().remove();
		}
	});
}

function unsetNewRows() {
	setTimeout(function() {
		$('tr.newrow').removeClass();
	}, 3000);
}

function setAddTabAction() {
	$("#addTab").click(function(){
		addTab();
	});
}

function addTab() {
	var ts = Math.round(new Date().getTime());

	//Add tab
	var tabCode = "<li id='tab_" + ts + "'><a data-toggle='tab' href='#" + ts + "'>New Tab</a></li>";
	$(tabCode).insertBefore("#historyTab");

	//Add Body
	var tabBody = "<div id='" + ts + "' class='tab-pane fade'><br/><table class='table table-condensed pricetable reorder'><thead><tr><th></th><th>Structure</th><th>Notional / DV01</th><th>Level</th><th>Unit</th><th></th><th></th><th></th><th></th><th></th></tr></thead><tbody></tbody></table></div>";
	$(tabBody).insertBefore("#historyBody");

	//Activate new tab
	$(".nav-tabs li#tab_" + ts + " a").tab('show');
}

function checkTime(i) {
	return (i < 10) ? "0" + i : i;
}

function getTime() {
	var today = new Date();
	return checkTime(today.getHours()) + ":" + checkTime(today.getMinutes()) + ":" + checkTime(today.getSeconds());
}