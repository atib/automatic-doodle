	// $('.table-input').on("blur", function(){

		
	// 	rowCCY = $(this).parents("td").eq(0);

	// 	rowStructure = $(this).val();

	// 	rowCCY = rowCCY.siblings().eq(0).children().val(); 
	// 	newStructure = rowCCY;
	
	// 	var parent = $(this).parents("td").parents("table");

	// 	if (rowStructure.includes("fly")) {

	// 		console.log('includes fly - ', new Date(), rowStructure);
	// 		newStructure += rowStructure;
	// 		addRow(newStructure);
			


	// 	} else {

	// 		console.log('does not include fly');

	// 		if (parent.siblings('.pricerow-legs')) {
	// 				pricelegs = $(this).parents("td").parents("table").siblings('.pricerow-legs').detach();
	// 				edit_icon = $(this).parents("td").eq(0).siblings().eq(4).children().detach();
	// 		}
	// 	} 
	// });